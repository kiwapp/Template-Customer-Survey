Kiwapp.set({
    appParameters : {"osID":"webbrowser","deviceIdentifier":"b4ffe18d33533e3def119f74ba341400","appInstanceId":"200","driverVersion":"4.2.1","shopId":"95"},
    shopParameters : {Class_Parse_name:"Customer-survey",
X_Parse_Application_Id:"SsNc2beriSMghddtEc78DQ8B2GzpjOBI7Muqhjqh",
X_Parse_REST_API_Key:"4nVYnxxI3wukGvGYgCUPo9YO4hBqpvjdlfBI2679",},
    shopInfosConfig : {"external_identifier":"00001","address1":"1 rue de ben","address2":"","address3":"","zipcode":"78270","phone":"","name":"ben","country_id":"72","country_name":"France"}
});